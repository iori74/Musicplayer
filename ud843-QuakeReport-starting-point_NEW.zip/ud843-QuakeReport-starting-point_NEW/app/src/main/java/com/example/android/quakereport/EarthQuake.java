package com.example.android.quakereport;

public class EarthQuake {
    private final double mMagnitude;
    private final String mLocation;
    private long mTimeInMilliseconds;
    private String mUrl;

    public EarthQuake(double amplitude, String location,long timeInMilliseconds, String url) {
        mMagnitude = amplitude;
        mTimeInMilliseconds = timeInMilliseconds;
        mLocation = location;
        mUrl = url;
    }

    public double getMagnitude() {
        return mMagnitude;
    }


    public long getTimeInMilliseconds() {
        return mTimeInMilliseconds;
    }

    public String getLocation() {
        return mLocation;
    }
    public String getUrl() {
        return mUrl;
    }
}
